import 'package:flutter/material.dart';

class Dot extends StatelessWidget {
  final bool isActive;

  Dot({required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 5),
      height: 10,
      width: 10,
      decoration: BoxDecoration(
        color: isActive ? Colors.greenAccent : Colors.white24,
        shape: BoxShape.circle,
      ),
    );
  }
}
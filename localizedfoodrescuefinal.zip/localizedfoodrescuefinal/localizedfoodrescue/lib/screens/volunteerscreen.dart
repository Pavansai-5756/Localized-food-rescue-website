import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class VolunteerScreen extends StatefulWidget {
  const VolunteerScreen({super.key});

  @override
  State<VolunteerScreen> createState() => _VolunteerScreenState();
}

class _VolunteerScreenState extends State<VolunteerScreen> {
  late GoogleMapController mapController;

  // Sample donor location (MG Road, Bangalore)
  final LatLng donorLocation = const LatLng(12.9766, 77.5993);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Volunteer Dashboard")),
      body: GoogleMap(
        onMapCreated: (GoogleMapController controller) {
          mapController = controller;
        },
        initialCameraPosition: CameraPosition(
          target: donorLocation,
          zoom: 15.0,
        ),
        markers: {
          Marker(
            markerId: const MarkerId('donorLocation'),
            position: donorLocation,
            infoWindow: const InfoWindow(
              title: 'Donor Location',
              snippet: 'MG Road, Bangalore',
            ),
          ),
        },
      ),
    );
  }
}

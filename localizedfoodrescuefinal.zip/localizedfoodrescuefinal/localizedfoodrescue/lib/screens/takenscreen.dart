import 'package:flutter/material.dart';

class TakerScreen extends StatelessWidget {
  const TakerScreen({super.key});

  // ✅ Fully working Indian food images
  final List<Map<String, String>> foodPosts = const [
    {
      'name': 'Rice & Curry',
      'location': 'MG Road, Bangalore',
      'imageUrl': 'https://www.themealdb.com/images/media/meals/wyxwsp1486979827.jpg'
    },
    {
      'name': 'Veg Biryani',
      'location': 'JP Nagar, Bangalore',
      'imageUrl': 'https://www.themealdb.com/images/media/meals/xrttsx1487339558.jpg'
    },
    {
      'name': 'Chapati & Sabzi',
      'location': 'Indiranagar, Bangalore',
      'imageUrl': 'https://www.themealdb.com/images/media/meals/xxpqsy1511452222.jpg'
    },
    {
      'name': 'Fried Rice',
      'location': 'Koramangala, Bangalore',
      'imageUrl': 'https://www.themealdb.com/images/media/meals/1529444830.jpg'
    },
    {
      'name': 'Sambar Rice',
      'location': 'Whitefield, Bangalore',
      'imageUrl': 'https://www.themealdb.com/images/media/meals/xvsurr1511719182.jpg' // ✅ New working URL
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Taker Dashboard")),
      body: ListView.builder(
        itemCount: foodPosts.length,
        itemBuilder: (context, index) {
          final post = foodPosts[index];

          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            elevation: 4,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  post['imageUrl']!,
                  width: 60,
                  height: 60,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                  const Icon(Icons.broken_image, size: 60),
                ),
              ),
              title: Text(
                post['name']!,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(post['location']!),
              trailing: const Icon(Icons.fastfood, color: Colors.deepOrange),
            ),
          );
        },
      ),
    );
  }
}

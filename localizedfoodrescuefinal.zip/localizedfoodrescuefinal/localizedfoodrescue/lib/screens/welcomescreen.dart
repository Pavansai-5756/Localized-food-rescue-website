import 'package:flutter/material.dart';

class WelcomeScreen extends StatefulWidget {
  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  int currentIndex = 0;

  final List<Map<String, String>> onboardingData = [
    {
      'image': 'assets/img/photo2.jpg',
      'title': 'Dont waste the food',
      'subtitle': 'DONOTE THE FOOD '
    },
    {
      'image': 'assets/img/photo1.jpg',
      'title': 'HELP THOSE WHO DONT HAVE FOOD',
      'subtitle': 'HELPING IS THE BEST THING'
    },
    {
      'image': 'assets/img/photo2.jpg',
      'title': 'TREAT EVERY PERSONS AS A FRIEND',
      'subtitle': 'Your food is on its way!'
    },
  ];

  void nextPage() {
    if (currentIndex < onboardingData.length - 1) {
      setState(() {
        currentIndex++;
      });
    } else {
      Navigator.pushNamed(context, '/login'); // Or home
    }
  }

  @override
  Widget build(BuildContext context) {
    final data = onboardingData[currentIndex];

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(
          children: [
            // Main Onboarding Content
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SizedBox(height: 60), // Space for top buttons
                Image.asset(data['image']!, height: 250),
                Column(
                  children: [
                    Text(
                      data['title']!,
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.red),
                    ),
                    SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        data['subtitle']!,
                        textAlign: TextAlign.center,
                        style:
                        TextStyle(fontSize: 14, color: Colors.black54),
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    // Dot Indicators
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: List.generate(onboardingData.length, (index) {
                        return Container(
                          margin: EdgeInsets.all(4),
                          width: currentIndex == index ? 12 : 8,
                          height: currentIndex == index ? 12 : 8,
                          decoration: BoxDecoration(
                            color: currentIndex == index
                                ? Colors.red
                                : Colors.grey.shade300,
                            shape: BoxShape.circle,
                          ),
                        );
                      }),
                    ),
                    SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: nextPage,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        padding: EdgeInsets.symmetric(
                            horizontal: 40, vertical: 12),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30)),
                      ),
                      child: Text(
                        currentIndex == onboardingData.length - 1
                            ? 'Start'
                            : 'Next',
                        style:
                        TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ],
            ),

            // Top-right Login & Register
            Positioned(
              top: 10,
              right: 10,
              child: Row(
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/login');
                    },
                    child: Text("Login",
                        style: TextStyle(color: Colors.red)),
                  ),
                  SizedBox(width: 10),
                  TextButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/register');
                    },
                    child: Text("Register",
                        style: TextStyle(color: Colors.red)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
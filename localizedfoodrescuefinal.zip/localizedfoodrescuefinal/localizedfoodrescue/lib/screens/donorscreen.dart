import 'package:flutter/material.dart';
import 'package:location/location.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';

class DonorScreen extends StatefulWidget {
  const DonorScreen({Key? key}) : super(key: key);

  @override
  State<DonorScreen> createState() => _DonorScreenState();
}

class _DonorScreenState extends State<DonorScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _quantityController = TextEditingController();
  final TextEditingController _typeController = TextEditingController();
  final TextEditingController _pickupTimeController = TextEditingController();
  File? _image;
  String? _location;

  Future<void> _getLocation() async {
    Location location = Location();
    bool serviceEnabled = await location.serviceEnabled();
    if (!serviceEnabled) {
      serviceEnabled = await location.requestService();
    }
    PermissionStatus permissionGranted = await location.hasPermission();
    if (permissionGranted == PermissionStatus.denied) {
      permissionGranted = await location.requestPermission();
    }
    if (permissionGranted == PermissionStatus.granted) {
      final loc = await location.getLocation();
      setState(() {
        _location = "Lat: ${loc.latitude}, Lng: ${loc.longitude}";
      });
    }
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  void _submitListing() {
    if (_formKey.currentState!.validate()) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Food listed successfully!')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Donor Dashboard")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              const Text("Quick 2-click Food Listing", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              TextFormField(
                controller: _quantityController,
                decoration: const InputDecoration(labelText: "Quantity (e.g., 5 meals)"),
                validator: (value) => value!.isEmpty ? 'Enter quantity' : null,
              ),
              TextFormField(
                controller: _typeController,
                decoration: const InputDecoration(labelText: "Food Type (e.g., Rice, Curry)"),
                validator: (value) => value!.isEmpty ? 'Enter food type' : null,
              ),
              TextFormField(
                controller: _pickupTimeController,
                decoration: const InputDecoration(labelText: "Pickup Time (e.g., 7 PM)"),
                validator: (value) => value!.isEmpty ? 'Enter pickup time' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _pickImage,
                icon: const Icon(Icons.camera_alt),
                label: const Text("Add Photo"),
              ),
              if (_image != null)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Image.file(_image!, height: 150),
                ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _getLocation,
                icon: const Icon(Icons.location_on),
                label: const Text("Get Location Automatically"),
              ),
              if (_location != null)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Text("Location: $_location"),
                ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitListing,
                child: const Text("Submit Listing"),
              )
            ],
          ),
        ),
      ),
    );
  }
}

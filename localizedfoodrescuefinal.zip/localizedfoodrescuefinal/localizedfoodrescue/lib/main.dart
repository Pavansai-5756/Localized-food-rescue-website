import 'package:flutter/material.dart';
import 'screens/loginscreen.dart';
import 'screens/registerscreen.dart';
import 'screens/welcomescreen.dart';
import 'screens/donorscreen.dart';
import 'screens/volunteerscreen.dart';
import 'screens/takenscreen.dart';

void main() {
  runApp(FoodRescueApp());
}

class FoodRescueApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Food Rescue',
      initialRoute: '/',
      routes: {
        '/': (context) => WelcomeScreen(),     // ← No const
        '/login': (context) => LoginScreen(),  // ← No const
        '/register': (context) => RegisterScreen(),
        '/donor': (context) => DonorScreen(),
        '/volunteer': (context) => VolunteerScreen(),
        '/taker': (context) => TakerScreen(),
      },
    );
  }
}

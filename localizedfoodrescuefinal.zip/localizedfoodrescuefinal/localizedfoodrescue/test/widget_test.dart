import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:localizedfoodrescue/main.dart'; // Import your main app file

void main() {
  testWidgets('App loads welcome screen', (WidgetTester tester) async {
    // Load your actual app
    await tester.pumpWidget(FoodRescueApp());

    // Check that Welcome or Login/Buttons show up
    expect(find.text('Login'), findsOneWidget);
    expect(find.text('Register'), findsOneWidget);
  });
}
